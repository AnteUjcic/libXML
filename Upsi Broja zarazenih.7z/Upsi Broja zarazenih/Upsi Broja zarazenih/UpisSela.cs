﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace Upsi_Broja_zarazenih
{
    public partial class UpisSela : Form
    {
        List<Selo> upisKList = new List<Selo>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "selo.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);
        public UpisSela()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnUpisSela_Click(object sender, EventArgs e)
        {

            Selo selo = new Selo(txtUpisSela.Text, Convert.ToInt32(txtIDSela.Text), Convert.ToInt32(txtBrojStanovnika.Text));
            upisKList.Add(selo);
            try
            {
                var Selo = XDocument.Load(path);
                foreach (Selo upisUXml in upisKList)
                {
                    var Sela = new XElement("Selo",
                        new XElement("Ime", upisUXml.ImeSela),
                        new XElement("ID", upisUXml.IDSela1),
                        new XElement("Broj_stanovnika", upisUXml.BrojStanovnika1));
                    Selo.Root.Add(Sela);

                }
                Selo.Save(path);
            }
            catch (Exception ex)
            {
               
                var Selo = new XDocument();
                Selo.Add(new XElement("Selo"));
                foreach (Selo upis in upisKList)
                {
                    var Sela = new XElement("Selo",
                        new XElement("Ime", upis.ImeSela),
                        new XElement("ID", upis.IDSela1),
                        new XElement("Broj_stanovnika", upis.BrojStanovnika1));
                    Selo.Root.Add(Sela);
                }

                

                Selo.Save(path);


            }
            upisKList.Clear();
            this.Close();

            txtBrojStanovnika.Text = "";
            txtIDSela.Text = "";
            txtUpisSela.Text = "";

           
        }

        private void txtUpisSela_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIDSela_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
